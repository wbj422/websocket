<?php

/**
 * Created by PhpStorm.
 * User: wbj
 * Date: 2016/11/14
 * Time: 17:52
 */
class Model
{
    //获取条件
    public static function getWhere($data){
        $str = " ";
        foreach($data as $key=>$val){
            //如果值是一个数组的话，要将数组分解
            if(is_array($val)){
                $str .= ($key.$val[0]."'".$val[1]."' and ");
            }
            else{
                $str .= ($key."='".$val."' and ");
            }

        }
        $str = substr($str,0,strlen($str)-4);
        return $str;
    }

}