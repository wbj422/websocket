<?php

/**
 * Created by PhpStorm.
 * User: wbj
 * Date: 2016/11/14
 * Time: 17:52
 */
use GatewayWorker\Lib\Gateway;
use GatewayWorker\Lib\Db;
include_once (dirname(__FILE__)."/Model.class.php");
class UserModel extends Model
{
    //通过id获取一个用户
    public static function getUserById($user_id){
        $where = "user_id = ".$user_id;
        return Db::instance('db1')->select('*')->from('chat_user')->where($where)->limit(1)->query()[0];
    }

    public static function getUserByWhere($where){
        return Db::instance('db1')->select('*')->from('chat_user')->where($where)->query();
    }

    //修改用户
    public static function editUserByWhere($data,$where){
        $where = self::getWhere($where);
        return Db::instance('db1')->update('chat_user')->cols($data)->where($where)->query();
    }

}