<?php
/**
 * 配置控制器
 * User: MBENBEN
 * Date: 2017/1/11
 * Time: 14:25
 */
    class config{
        public static $host = "http://";

    }
