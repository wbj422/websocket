<?php
/*
 * 分发消息到各自的控制器
 */
include_once (dirname(__FILE__)."/LoginController.class.php");
class RouteController{

    //分发消息到各自的控制器   并且获得返回的结果
    public static function send($client_id,$message){
        //打印出收到的消息
        echo "get:".$message."\r\n\r";
        //将消息转化成
        $message_data = json_decode($message, true);
        switch($message_data['type']){
            case "login": //用户登录登陆
                LoginController::login($client_id,$message_data);
                break;
            default:break;
        }
    }

    //断开服务器处理分发
    public static function get($client_id){
        echo "-------------".date('Y-m-d H:i:s').$_SESSION['user_id']."close------\r\n\r";
        LogoutController::socketClose($client_id);
    }
}


?>
