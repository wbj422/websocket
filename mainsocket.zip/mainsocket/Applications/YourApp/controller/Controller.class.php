<?php
/*
 * 处理用户一些的设置
 */
use GatewayWorker\Lib\Gateway;
use GatewayWorker\Lib\Db;
include_once (dirname(__FILE__)."/ConfigController.class.php");
class Controller{

    /*
     * 添加一条消息记录
     * param $data array 消息记录数组
     * */
    public static function insertRecord($data){
        return $msg_id = Db::instance('db1')->insert("chat_msg")->cols($data)->query();
    }

    /*
     * 将消息标记为已读
     * param $msg_id int 消息记录id
     * */
    public static function readMsg($msg_id){
        Db::instance('db1')->update('chat_msg')->cols(array("msg_is_deal"=>1,"msg_dealtime"=>date('Y-m-d H:i:s')))->where('msg_id='.$msg_id)->query();
    }

    /*
     * 发送消息
     * param $msg array 消息数组
     * param $user_id int 接收消息的用户id
     * */
    public static function sendMsg($msg,$user_id){
        $msg = json_encode($msg);
        Gateway::sendToUid($user_id,$msg);
    }

    /*
     * 返回消息发送成功
     * param $msg_id int 客户端发送过来的msg
     * */
    public static function sendBack($msg_id){
        if($msg_id){
            $msg = '{"type":"back","msg_id":"'.$msg_id.'","msg":"success","time":"'.date("Y-m-d H:i:s").'"}';
            Gateway::sendToCurrentClient($msg);
        }
    }

    /*
     * 发送推送
     * param $user array 接收推送的用户数组，需要包含user_bs user_id user_regid
     * param $title string
     * param $content string
     * param $receiver string
     * */
    public static function doSendMessage($user,$title,$content,$receiver){
        //判断好友是否黑屏或者不在线，黑屏直接发推送
        if(($user['user_bs'] == 1 ||  !Gateway::isUidOnline($user['user_id']) ) && $user['user_regid']){ //黑屏 并且绑定了regid
            echo "doSendMessage-----\r\n\r";
            self::sendMessage($title,$content,$receiver);
        }
    }

    /*
     * 发送推送
     * param $title string
     * param $content string
     * param $receiver string
     * */
    public static function sendMessage($title,$content,$receiver){
        echo "!!!!!"."\r\n\r";
        echo $content."\r\n\r";
        echo $title."\r\n\r";
        echo $receiver."\r\n\r";
        if($receiver){
            $url = config::$host."/chat/index.php?m=Admin&c=jpush&a=pushMess&title=".$title."&content=".$content."&receiver=".$receiver;
            echo file_get_contents($url);
        }
    }
}







?>
