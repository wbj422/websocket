<?php
/*
 * 处理登陆
 */
use GatewayWorker\Lib\Gateway;
use GatewayWorker\Lib\Db;
include_once (dirname(__FILE__)."/ConfigController.class.php");
class LogoutController{

    public static $message;
    public static $client_id;
    //处理退出
    public static function logout($client_id,$message_data){
        //断开当前用户   ----会返回Events.php ---- RouteController.class.php  ------LogoutController.class.php ------ socketClose()
        Gateway::closeCurrentClient();
    }

    //处理socket断开
    public static function socketClose($client_id){
        //通知当前用户的好友，它已经下线
        echo "socketClose"."\r\n\r";
        if($_SESSION['user_id']){
            $user_id = $_SESSION['user_id'];
        }
        else{
            $user_id = Gateway::getSession($client_id)['user_id'];
        }
        if($user_id){
            //获取好友
            $friends = Db::instance('db1')->select('*')->from('chat_user_friends')->where("user_id=".$user_id)->query();
            //循环这些好友，如果好友在线就通知好友
            foreach($friends as $f){
                //获取在线状态的好友
                if(Gateway::isUidOnline($f['friend_user_id'])){   //在线
                    $msg['type'] = "user_state";
                    $msg['user_id'] = $_SESSION['user_id']."";
                    $msg['online'] = "false";
                    $msg = json_encode($msg);
                    Gateway::sendToUid($f['friend_user_id'],$msg);    //发送上线通知给这个朋友
                    unset($msg);
                }
            }
            //更改自己数据库的状态
            Db::instance('db1')->update('chat_user')->cols(array('user_online'=>'false'))->where('user_id='.$_SESSION['user_id'])->query();
        }
    }


}


?>
