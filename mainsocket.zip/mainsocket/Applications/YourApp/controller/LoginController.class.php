<?php
/*
 * 处理登陆
 */
use GatewayWorker\Lib\Gateway;
use GatewayWorker\Lib\Db;
include_once (dirname(__FILE__)."/Controller.class.php");
include_once (dirname(__FILE__)."/ConfigController.class.php");
include_once (dirname(__FILE__)."/../model/UserModel.class.php");
include_once (dirname(__FILE__)."/../model/AdminModel.class.php");

class LoginController extends Controller
{

    public static $message;
    public static $client_id;
    //处理登陆
    public static function login($client_id,$message_data){
        self::$message = $message_data;
        self::$client_id = $client_id;
        //用户登录
        if($message_data['identity'] == "user"){
            self::userLogin();
        }
        //管理员登录
        else if($message_data['identity'] == "admin"){
            self::adminLogin();
        }
    }

    //用户登录
    public static function userLogin(){
        //判断账号密码是否正确，正确的话 分配session
        $where = "user_account = '".self::$message['account']."'"." and user_password = '".self::$message['password']."'";
        $user = Db::instance('db1')->select('*')->from('chat_user')->where($where)->limit(1)->query();
        $user = $user[0];
        if($user){
            //登陆成功！
            //判断之前是否已经有人登陆了这个账号
            $old_client_id = Gateway::getClientIdByUid($user['user_id'])[0];  //一个client_id 只绑定一个uid
            if($old_client_id){ //有人就踢掉
                $msg['type'] = "user_state";
                $msg['online'] = "false";
                $msg['user_id'] = $user['user_id'];
                $msg['token'] = Gateway::getSession($old_client_id)['token'];
                $msg = json_encode($msg);
                //发送一条消息告诉对方
                Gateway::sendToClient($old_client_id,$msg);
                //然后踢掉
                Gateway::closeClient($old_client_id);
                //todo  下线了又上线所以不写下线通知
            }
            //设置session
            $_SESSION['login'] = true;    //登陆识别
            $_SESSION['token'] = $user['user_token'];
            $_SESSION['user_id'] = $user['user_id'];
            $_SESSION['user_nickname'] = $user['user_nickname'];
            $_SESSION['user_headimgurl'] = $user['user_headimgurl'];
            $_SESSION['user_sex'] = $user['user_sex'];
            $_SESSION['user_account'] = $user['user_account'];
            $_SESSION['user_bs'] = 1;   //开屏
            //绑定uid
            Gateway::bindUid(self::$client_id,$user['user_id']);
            //告诉自己已经登陆成功
            unset($msg);
            $msg['type'] = "login";
            $msg['msg'] = "success";
            $msg['time'] = date("Y-m-d H:i:s");
            $msg = json_encode($msg);
            Gateway::sendToCurrentClient($msg);
            //告诉自己的好友上线了
            $online_list = self::onLine();
            self::sendOnlineList($online_list);
            //发送好友在线列表
            //修改自己的数据库状态 user_online  true
            Db::instance('db1')->update('chat_user')->cols(array('user_online'=>'true'))->where('user_id='.$user['user_id'])->query();

        }
        else{
            //返回登陆失败！
            $msg['type'] = "login";
            $msg['msg'] = "false";
            $msg['time'] = date("Y-m-d H:i:s");
            $msg = json_encode($msg);
            Gateway::sendToCurrentClient($msg);
        }
    }

    //告诉自己的好友上线了
    public static function onLine(){
        //获取好友
        $friends = Db::instance('db1')->select('*')->from('chat_user_friends')->where("user_id=".$_SESSION['user_id'])->query();
        $online_list = [];   //
        //循环这些好友，如果好友在线就通知好友
        foreach($friends as $f){
            $where = "user_id = ".$f['friend_user_id']." and user_online = 'true'";
            //获取在线状态的好友
            $u = Db::instance('db1')->select('*')->from('chat_user')->where($where)->limit(1)->offset(0)->query()[0];
            if($u){ //在线
                $online_list[] = $f['friend_user_id']."";
                $msg['type'] = "user_state";
                $msg['user_id'] = $_SESSION['user_id']."";
                $msg['online'] = "true";
                $msg = json_encode($msg);
                Gateway::sendToUid($u['user_id'],$msg);    //发送上线通知给这个朋友
                unset($msg);
            }
            unset($u);
        }
        return $online_list;
    }

    public static function sendOnlineList($online_list){
        $msg['type'] = "online_list";
        $msg['list'] = $online_list;
        $msg = json_encode($msg);
        Gateway::sendToCurrentClient($msg);
    }

    //管理员登陆
    public static function adminLogin(){
        //判断账号密码是否正确
        $where = [];
        $where['admin_account'] = self::$message['account'];
        $where['admin_password'] = self::$message['password'];
        $admin = AdminModel::getOneAdminByWhere($where);
        if($admin){ //登陆成功
            //绑定uid
            Gateway::bindUid(self::$client_id,"admin".$admin['admin_id']);
            //设置session
            $_SESSION['login'] = true ;
            $_SESSION['identity'] = "admin";
            $_SESSION['admin_id'] = $admin['admin_id'];
            //发送消息
            unset($msg);
            $msg['type'] = "login";
            $msg['msg'] = "success";
            $msg['time'] = date("Y-m-d H:i:s");
            self::sendMsg($msg,"admin".$admin['admin_id']);
        }
    }
}


?>
